<?php
require_once "conexion.php";
$data = json_decode(file_get_contents('php://input'), true);
$carrito = $data['carrito'] ?? [];
$monto = $data['monto'] ?? 0;

if (!$carrito) {
    echo json_encode(['success' => false]);
    exit;
}

// Obtener los nombres de los productos separados por coma
$nombres = array_map(function($item) {
    return $item['nombre'];
}, $carrito);
$pedido_str = implode(', ', $nombres);

// Insertar pedido en pedidos_detal
$stmt = $conn->prepare("INSERT INTO pedidos_detal (pedido, monto, estado) VALUES (?, ?, 'sin_enviar')");
$stmt->bind_param("sd", $pedido_str, $monto);
$stmt->execute();
$pedido_id = $conn->insert_id;
$stmt->close();

// Insertar detalles en pedido_detalle
$stmt = $conn->prepare("INSERT INTO pedido_detalle (pedido_id, producto_id, nombre, precio, cantidad) VALUES (?, ?, ?, ?, ?)");
foreach ($carrito as $item) {
    $stmt->bind_param("iisdi", $pedido_id, $item['id'], $item['nombre'], $item['precio'], $item['cantidad']);
    $stmt->execute();
}
$stmt->close();

echo json_encode(['success' => true, 'pedido_id' => $pedido_id]);
?>