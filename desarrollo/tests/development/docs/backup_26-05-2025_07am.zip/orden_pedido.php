<?php
require_once "conexion.php";

// Obtener categorías
$categorias = [];
$sql_cat = "SELECT DISTINCT categoria FROM productos WHERE activo = 1 ORDER BY categoria ASC";
$res_cat = $conn->query($sql_cat);
while ($row = $res_cat->fetch_assoc()) {
    $categorias[] = $row['categoria'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Orden de Pedido</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* VSCode Theme Variables */
        :root {
            --vscode-bg: #1e1e1e;
            --vscode-sidebar: #252526;
            --vscode-border: #3c3c3c;
            --vscode-text: #d4d4d4;
            --vscode-text-muted: #969696;
            --apple-blue: #007aff;
            --apple-blue-hover: #0056b3;
            --apple-green: #30d158;
            --apple-red: #ff453a;
            --apple-orange: #ff9f0a;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: var(--vscode-bg);
            color: var(--vscode-text);
            line-height: 1.6;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: var(--vscode-sidebar);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .logo {
            height: 50px;
            width: auto;
            margin-right: 15px;
            vertical-align: middle;
            object-fit: contain;
        }

        h1 {
            display: inline-block;
            vertical-align: middle;
            font-size: 2rem;
            font-weight: 600;
            margin: 0;
            color: var(--vscode-text);
        }

        .form-row {
            margin-bottom: 24px;
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
        }

        select, input[type="text"], input[type="number"] {
            flex: 1;
            min-width: 200px;
            padding: 12px 16px;
            border: 1px solid var(--vscode-border);
            border-radius: 8px;
            background: var(--vscode-bg);
            color: var(--vscode-text);
            font-size: 14px;
            transition: all 0.2s ease;
        }

        select:focus, input:focus {
            outline: none;
            border-color: var(--apple-blue);
            box-shadow: 0 0 0 3px rgba(0, 122, 255, 0.1);
        }

        input[type="text"]::placeholder {
            color: var(--vscode-text-muted);
        }

        /* Tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: var(--vscode-bg);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }

        th, td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid var(--vscode-border);
        }

        th {
            background: var(--vscode-sidebar);
            font-weight: 600;
            color: var(--vscode-text);
            font-size: 14px;
        }

        td {
            font-size: 14px;
        }

        tr:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        /* Column widths for product table */
        #productos-list table th:nth-child(1), #productos-list table td:nth-child(1) { width: 40%; }
        #productos-list table th:nth-child(2), #productos-list table td:nth-child(2) { width: 20%; }
        #productos-list table th:nth-child(3), #productos-list table td:nth-child(3) { width: 20%; }
        #productos-list table th:nth-child(4), #productos-list table td:nth-child(4) { width: 20%; }

        /* Buttons */
        .btn {
            padding: 10px 20px;
            background: var(--apple-blue);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            min-width: 80px;
        }

        .btn:hover {
            background: var(--apple-blue-hover);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 122, 255, 0.3);
        }

        .btn:active {
            transform: translateY(0);
        }

        .btn-danger {
            background: var(--apple-red);
        }

        .btn-danger:hover {
            background: #e60026;
        }

        /* Cart section */
        .totalizador {
            margin-top: 32px;
            padding: 24px;
            background: var(--vscode-sidebar);
            border-radius: 12px;
            border: 1px solid var(--vscode-border);
        }

        .totalizador h2 {
            margin: 0 0 16px 0;
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--vscode-text);
        }

        .totalizador h3 {
            font-size: 1.25rem;
            font-weight: 600;
            margin: 16px 0 0 0;
            text-align: right;
            color: var(--apple-blue);
        }

        /* Product list styling */
        #productos-list p {
            text-align: center;
            color: var(--vscode-text-muted);
            font-style: italic;
            padding: 20px;
        }

        /* Order completion section */
        #finalizar-pedido {
            margin-top: 32px;
            text-align: center;
        }

        #finalizar-pedido .btn {
            font-size: 16px;
            padding: 14px 32px;
            background: var(--apple-blue);
        }

        #finalizar-pedido .btn:hover {
            background: var(--apple-blue-hover);
        }

        #pedido-url {
            margin-top: 24px;
            text-align: center;
            padding: 20px;
            background: var(--vscode-bg);
            border-radius: 8px;
            border: 1px solid var(--vscode-border);
        }

        #pedido-url p {
            margin: 0 0 16px 0;
            font-weight: 500;
        }

        #pedido-link {
            width: 80%;
            margin-bottom: 16px;
        }

        /* Loading and animations */
        .loading {
            text-align: center;
            color: var(--vscode-text-muted);
            padding: 20px;
        }

        .loading::after {
            content: '';
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 2px solid var(--vscode-border);
            border-top: 2px solid var(--apple-blue);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Header styling */
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 32px;
            padding-bottom: 24px;
            border-bottom: 1px solid var(--vscode-border);
        }

        /* Form improvements */
        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--vscode-text);
            font-size: 14px;
        }

        /* Search section */
        .search-section {
            background: var(--vscode-bg);
            padding: 20px;
            border-radius: 8px;
            border: 1px solid var(--vscode-border);
            margin-bottom: 24px;
        }

        .search-section h3 {
            margin: 0 0 16px 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--vscode-text);
        }

        /* Product grid alternative layout */
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 16px;
            margin-top: 20px;
        }

        .product-card {
            background: var(--vscode-sidebar);
            border: 1px solid var(--vscode-border);
            border-radius: 8px;
            padding: 16px;
            transition: all 0.2s ease;
        }

        .product-card:hover {
            border-color: var(--apple-blue);
            box-shadow: 0 4px 12px rgba(0, 122, 255, 0.2);
        }

        .product-card h4 {
            margin: 0 0 8px 0;
            font-size: 16px;
            font-weight: 600;
            color: var(--vscode-text);
        }

        .product-card .price {
            font-size: 18px;
            font-weight: 600;
            color: var(--apple-blue);
            margin-bottom: 12px;
        }

        .product-card .quantity-controls {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 12px;
        }

        .product-card .quantity-controls input {
            width: 60px;
            text-align: center;
        }

        /* Cart enhancements */
        .cart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }

        .cart-header .clear-cart {
            background: var(--apple-red);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .cart-header .clear-cart:hover {
            background: #e60026;
        }

        /* Success message */
        .success-message {
            background: rgba(48, 209, 88, 0.1);
            border: 1px solid var(--apple-green);
            color: var(--apple-green);
            padding: 16px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
        }

        /* Error message */
        .error-message {
            background: rgba(255, 69, 58, 0.1);
            border: 1px solid var(--apple-red);
            color: var(--apple-red);
            padding: 16px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
        }

        /* Link styling */
        a {
            color: var(--apple-blue);
            text-decoration: none;
            transition: color 0.2s ease;
        }

        a:hover {
            color: var(--apple-blue-hover);
            text-decoration: underline;
        }

        /* Badge styling */
        .badge {
            background: var(--apple-blue);
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
        }

        .badge.cart-count {
            background: var(--apple-red);
            margin-left: 8px;
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--vscode-bg);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--vscode-border);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .container {
                margin: 10px;
                padding: 16px;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 16px;
            }

            .form-row {
                flex-direction: column;
            }

            select, input[type="text"], input[type="number"] {
                min-width: auto;
            }

            table {
                font-size: 12px;
            }

            th, td {
                padding: 8px;
            }

            h1 {
                font-size: 1.5rem;
            }

            .products-grid {
                grid-template-columns: 1fr;
            }

            .cart-header {
                flex-direction: column;
                gap: 12px;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>    <div class="container">
        <div class="header">
            <img src="logo.png" class="logo" alt="Sequoia Speed">
            <h1>Orden de Pedido Manual</h1>
        </div>
    <div class="search-section">
        <h3>Buscar Productos</h3>
        <div class="form-row">
            <select id="categoria">
                <option value="">Selecciona una categoría</option>
                <?php foreach ($categorias as $cat): ?>
                    <option value="<?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?></option>
                <?php endforeach; ?>
            </select>
            <input type="text" id="busqueda" placeholder="Escribe el nombre del producto">
        </div>
    </div>
    <div id="productos-list">
        <p>Selecciona una categoría o escribe un nombre para buscar productos.</p>
    </div>
    <div id="carrito" class="totalizador">
        <div class="cart-header">
            <h2>Carrito de Compras</h2>
            <button class="clear-cart" onclick="limpiarCarrito()">Limpiar Carrito</button>
        </div>
        <table id="carrito-table">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio</th>
                    <th>Total</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="5">Tu carrito está vacío.</td></tr>
            </tbody>
        </table>
        <h3>Total: $<span id="total">0</span></h3>
    </div>
    <div id="finalizar-pedido" style="margin-top:30px; text-align:center;">
        <button class="btn" onclick="finalizarPedido()">Finalizar Pedido</button>
    </div>
    <div id="pedido-url" style="display:none; margin-top:20px; text-align:center;">
        <p>Tu pedido ha sido generado. Comparte este enlace:</p>
        <input type="text" id="pedido-link" readonly style="width:80%;padding:8px;">
        <button class="btn" onclick="copiarLink()">Copiar</button>
    </div>
</div>
<script>
let carrito = [];

document.getElementById('categoria').addEventListener('change', cargarProductos);
document.getElementById('busqueda').addEventListener('input', cargarProductos);

function cargarProductos() {
    const categoria = document.getElementById('categoria').value;
    const busqueda = document.getElementById('busqueda').value.trim();
    const productosList = document.getElementById('productos-list');

    // Mostrar mensaje de carga
    productosList.innerHTML = '<div class="loading">Cargando productos...</div>';

    // Llamada AJAX para obtener los productos
    fetch(`productos_por_categoria.php?cat=${encodeURIComponent(categoria)}&search=${encodeURIComponent(busqueda)}`)
        .then(response => response.json())
        .then(data => {
            if (data.productos.length === 0) {
                productosList.innerHTML = '<p>No se encontraron productos.</p>';
                return;
            }

            let html = '<table><thead><tr><th>Nombre</th><th>Precio</th><th>Cantidad</th><th></th></tr></thead><tbody>';
            data.productos.forEach(producto => {
                html += `<tr>
                    <td>${producto.nombre}</td>
                    <td>$${producto.precio.toLocaleString()}</td>
                    <td><input type="number" min="1" max="100" value="1" id="cantidad_${producto.id}"></td>
                    <td><button class="btn" onclick="agregarAlCarrito(${producto.id}, '${producto.nombre}', ${producto.precio})">Agregar</button></td>
                </tr>`;
            });
            html += '</tbody></table>';
            productosList.innerHTML = html;
        })
        .catch(error => {
            console.error('Error al cargar los productos:', error);
            productosList.innerHTML = '<div class="error-message">Error al cargar los productos. Intenta nuevamente.</div>';
        });
}

function agregarAlCarrito(id, nombre, precio) {
    const cantidad = parseInt(document.getElementById(`cantidad_${id}`).value);
    if (isNaN(cantidad) || cantidad < 1) return;

    const index = carrito.findIndex(item => item.id === id);
    if (index >= 0) {
        carrito[index].cantidad += cantidad;
    } else {
        carrito.push({ id, nombre, precio, cantidad });
    }
    actualizarCarrito();
}

function actualizarCarrito() {
    const carritoTable = document.getElementById('carrito-table').querySelector('tbody');
    const totalElement = document.getElementById('total');
    carritoTable.innerHTML = '';
    let total = 0;

    carrito.forEach((item, index) => {
        const subtotal = item.precio * item.cantidad;
        total += subtotal;
        carritoTable.innerHTML += `
            <tr>
                <td>${item.nombre}</td>
                <td><input type="number" min="1" value="${item.cantidad}" onchange="modificarCantidad(${index}, this.value)"></td>
                <td>$${item.precio.toLocaleString()}</td>
                <td>$${subtotal.toLocaleString()}</td>
                <td><button class="btn btn-danger" onclick="eliminarDelCarrito(${index})">Eliminar</button></td>
            </tr>
        `;
    });

    if (carrito.length === 0) {
        carritoTable.innerHTML = '<tr><td colspan="5">Tu carrito está vacío.</td></tr>';
    }

    totalElement.textContent = total.toLocaleString();
}

function modificarCantidad(index, nuevaCantidad) {
    nuevaCantidad = parseInt(nuevaCantidad);
    if (isNaN(nuevaCantidad) || nuevaCantidad < 1) return;
    carrito[index].cantidad = nuevaCantidad;
    actualizarCarrito();
}

function eliminarDelCarrito(index) {
    carrito.splice(index, 1);
    actualizarCarrito();
}

function limpiarCarrito() {
    if (carrito.length === 0) return;
    if (confirm('¿Estás seguro de que quieres vaciar el carrito?')) {
        carrito = [];
        actualizarCarrito();
    }
}

function finalizarPedido() {
    if (carrito.length === 0) {
        mostrarMensaje('El carrito está vacío.', 'error');
        return;
    }
    
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = 'Procesando...';
    btn.disabled = true;
    
    const monto = carrito.reduce((acc, item) => acc + item.precio * item.cantidad, 0);
    fetch('guardar_pedido.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ carrito, monto })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            const url = `${window.location.origin}/pedidos/index.php?pedido=${data.pedido_id}`;
            document.getElementById('pedido-link').value = url;
            document.getElementById('pedido-url').style.display = 'block';
            document.getElementById('finalizar-pedido').style.display = 'none';
            mostrarMensaje('¡Pedido generado exitosamente!', 'success');
            // Limpiar carrito después del éxito
            carrito = [];
            actualizarCarrito();
        } else {
            mostrarMensaje('Error al guardar el pedido. Intenta nuevamente.', 'error');
            btn.textContent = originalText;
            btn.disabled = false;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarMensaje('Error de conexión. Intenta nuevamente.', 'error');
        btn.textContent = originalText;
        btn.disabled = false;
    });
}

function mostrarMensaje(texto, tipo) {
    // Remover mensajes anteriores
    const mensajesAnteriores = document.querySelectorAll('.success-message, .error-message');
    mensajesAnteriores.forEach(msg => msg.remove());
    
    const mensaje = document.createElement('div');
    mensaje.className = tipo === 'success' ? 'success-message' : 'error-message';
    mensaje.textContent = texto;
    
    // Insertar después del carrito
    const carrito = document.getElementById('carrito');
    carrito.parentNode.insertBefore(mensaje, carrito.nextSibling);
    
    // Auto-remover después de 5 segundos
    setTimeout(() => {
        if (mensaje.parentNode) {
            mensaje.remove();
        }
    }, 5000);
}

function copiarLink() {
    const input = document.getElementById('pedido-link');
    input.select();
    input.setSelectionRange(0, 99999);
    
    try {
        document.execCommand('copy');
        const btn = event.target;
        const originalText = btn.textContent;
        btn.textContent = '¡Copiado!';
        btn.style.background = 'var(--apple-green)';
        
        setTimeout(() => {
            btn.textContent = originalText;
            btn.style.background = 'var(--apple-blue)';
        }, 2000);
    } catch (err) {
        console.error('Error al copiar:', err);
        mostrarMensaje('Error al copiar el enlace', 'error');
    }
}
</script>
</body>
</html>