<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=UTF-8');
require_once "conexion.php";

$cat = isset($_GET['cat']) ? trim($_GET['cat']) : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$productos = [];

$query = "SELECT id, nombre, precio FROM productos WHERE activo = 1";
$params = [];
$types = "";

if (!empty($cat)) {
    $query .= " AND categoria = ?";
    $params[] = $cat;
    $types .= "s";
}

if (!empty($search)) {
    $query .= " AND nombre LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}

$stmt = $conn->prepare($query);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$stmt->bind_result($id, $nombre, $precio);

while ($stmt->fetch()) {
    $productos[] = [
        'id' => $id,
        'nombre' => $nombre,
        'precio' => $precio
    ];
}

$stmt->close();
echo json_encode(['productos' => $productos]);
?>