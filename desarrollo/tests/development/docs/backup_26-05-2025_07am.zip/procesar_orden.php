<?php
require_once "conexion.php";

// Función para mejorar el envío de emails con archivos adjuntos
function enviar_email_mejorado($to, $subject, $message, $headers = '', $archivo_path = null) {
    // Limpiar y normalizar headers
    $headers = trim($headers);
    
    // Headers por defecto si no se proporcionan
    if (empty($headers)) {
        $headers = "From: Sequoia Speed <ventas@sequoiaspeed.com.co>\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion();
    } else {
        // Asegurar que los headers terminen correctamente
        if (!preg_match('/\r\n$/', $headers)) {
            $headers .= "\r\n";
        }
        // Limpiar headers malformados
        $headers = preg_replace('/\r?\n/', "\r\n", $headers);
        $headers = preg_replace('/\r\n+/', "\r\n", $headers);
    }
    
    // Verificar que la función mail existe
    if (!function_exists('mail')) {
        error_log("ERROR: La función mail() no está disponible en este servidor");
        return false;
    }
    
    // Si hay archivo adjunto, crear email multipart
    if ($archivo_path && file_exists($archivo_path)) {
        $resultado = enviar_email_con_adjunto($to, $subject, $message, $headers, $archivo_path);
    } else {
        // Envío normal sin adjunto
        $resultado = mail($to, $subject, $message, $headers);
    }
    
    if ($resultado) {
        error_log("Email enviado exitosamente a: " . $to . " - Asunto: " . $subject);
        return true;
    } else {
        error_log("ERROR enviando email a: " . $to . " - Asunto: " . $subject);
        
        // Log adicional con información del sistema
        error_log("Información del sistema: OS=" . PHP_OS . ", PHP=" . PHP_VERSION);
        error_log("Configuración SMTP: " . ini_get('SMTP') . ":" . ini_get('smtp_port'));
        
        return false;
    }
}

// Función para enviar email con archivo adjunto
function enviar_email_con_adjunto($to, $subject, $message, $headers_base, $archivo_path) {
    // Generar boundary único
    $boundary = md5(time());
    
    // Extraer información del archivo
    $archivo_nombre = basename($archivo_path);
    $archivo_contenido = file_get_contents($archivo_path);
    $archivo_encoded = chunk_split(base64_encode($archivo_contenido));
    $archivo_tipo = mime_content_type($archivo_path);
    
    // Limpiar y preparar headers base
    $headers_base = trim($headers_base);
    $headers_base = preg_replace('/\r?\n/', "\r\n", $headers_base);
    
    // Headers para email multipart
    $headers = str_replace("Content-Type: text/plain; charset=UTF-8\r\n", "", $headers_base);
    $headers = rtrim($headers, "\r\n") . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"{$boundary}\"";
    
    // Construir el cuerpo del email multipart
    $email_body = "--{$boundary}\r\n";
    $email_body .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $email_body .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $email_body .= $message . "\r\n\r\n";
    
    // Adjuntar archivo
    $email_body .= "--{$boundary}\r\n";
    $email_body .= "Content-Type: {$archivo_tipo}; name=\"{$archivo_nombre}\"\r\n";
    $email_body .= "Content-Transfer-Encoding: base64\r\n";
    $email_body .= "Content-Disposition: attachment; filename=\"{$archivo_nombre}\"\r\n\r\n";
    $email_body .= $archivo_encoded . "\r\n";
    $email_body .= "--{$boundary}--";
    
    return mail($to, $subject, $email_body, $headers);
}

// Activar manejo de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'error.log');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pedido_id = $_POST['pedido_id'] ?? null;
    $monto = $_POST['monto'] ?? '';
    $nombre = $_POST['nombre'] ?? '';
    $direccion = $_POST['direccion'] ?? '';
    $telefono = $_POST['telefono'] ?? '';
    $correo = $_POST['correo'] ?? '';
    $persona_recibe = $_POST['persona_recibe'] ?? '';
    $horarios = $_POST['horarios'] ?? '';
    $metodo_pago = $_POST['metodo_pago'] ?? '';
    $comentario = $_POST['comentario'] ?? '';
    $pedido_texto = $_POST['pedido'] ?? '';
    
    // Datos específicos de Bold PSE si vienen del callback
    $bold_order_id = $_GET['orden'] ?? $_POST['bold_order_id'] ?? '';
    $pago_completado = $_GET['pago_completado'] ?? false;
    
    // Debug: Mostrar datos recibidos
    echo "<!-- DEBUG POST DATA: ";
    print_r($_POST);
    echo " GET DATA: ";
    print_r($_GET);
    echo " -->";
    
    // Limpiar monto si viene con formato
    $monto_limpio = preg_replace('/[^0-9.]/', '', $monto);
    
    // Validar datos obligatorios
    if (empty($nombre) || empty($direccion) || empty($telefono) || empty($correo)) {
        die("Error: Faltan campos obligatorios");
    }
    
    // Manejar archivo
    $archivo_nombre = null;
    if (isset($_FILES['comprobante']) && $_FILES['comprobante']['error'] == 0) {
        $upload_dir = 'uploads/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $archivo_nombre = time() . '_' . $_FILES['comprobante']['name'];
        $archivo_path = $upload_dir . $archivo_nombre;
        
        if (move_uploaded_file($_FILES['comprobante']['tmp_name'], $archivo_path)) {
            // Archivo subido exitosamente
        } else {
            $archivo_nombre = null;
        }
    }
    
    // Verificar conexión
    if (!$conn) {
        die("Error de conexión: " . mysqli_connect_error());
    }
    
    // Preparar el pedido_texto con los items del carrito si existe pedido_id
    $detalle_texto = "";
    if ($pedido_id) {
        // Obtener solo las columnas necesarias de pedido_detalle
        $sql_detalle = "SELECT nombre, precio, cantidad FROM pedido_detalle WHERE pedido_id = ?";
        $stmt_detalle = $conn->prepare($sql_detalle);
        if ($stmt_detalle) {
            $stmt_detalle->bind_param("i", $pedido_id);
            $stmt_detalle->execute();
            // CORREGIR: Solo 3 variables para 3 columnas
            $stmt_detalle->bind_result($det_nombre, $det_precio, $det_cantidad);
            
            $items = [];
            while ($stmt_detalle->fetch()) {
                $items[] = [
                    'nombre' => $det_nombre,
                    'precio' => $det_precio,
                    'cantidad' => $det_cantidad
                ];
            }
            $stmt_detalle->close();
            
            // Crear texto del pedido con los items
            if (!empty($items)) {
                $detalle_texto = "DETALLE DEL PEDIDO:\n";
                foreach ($items as $item) {
                    $subtotal = $item['precio'] * $item['cantidad'];
                    $detalle_texto .= "- " . $item['nombre'] . " x" . $item['cantidad'] . " = $" . number_format($subtotal, 0, ',', '.') . "\n";
                }
                $detalle_texto .= "\nTOTAL: $" . number_format($monto_limpio, 0, ',', '.');
            }
        }
    }
    
    // Si no hay detalle_texto del carrito, usar el pedido_texto del formulario
    $pedido_final = !empty($detalle_texto) ? $detalle_texto : $pedido_texto;
    
    // Insertar en pedidos_detal
    $sql = "INSERT INTO pedidos_detal (pedido, monto, nombre, direccion, telefono, correo, persona_recibe, horarios, metodo_pago, comprobante, comentario) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    
    // Verificar si prepare fue exitoso
    if (!$stmt) {
        die("Error preparando consulta: " . $conn->error);
    }
    
    // CORREGIR: 11 parámetros para 11 placeholders
    $stmt->bind_param("sdsssssssss", $pedido_final, $monto_limpio, $nombre, $direccion, $telefono, $correo, $persona_recibe, $horarios, $metodo_pago, $archivo_nombre, $comentario);
    
    if ($stmt->execute()) {
        $orden_id = $conn->insert_id;
        
        echo "<!-- DEBUG: Orden insertada con ID: " . $orden_id . " -->";
        
        // Manejar PSE Bold si corresponde
        if ($metodo_pago === 'PSE Bold' && !empty($bold_order_id)) {
            // Crear registro en tabla de pedidos Bold (si existe)
            $sql_bold = "INSERT INTO pedidos (
                bold_order_id, 
                nombre, 
                direccion, 
                telefono, 
                correo, 
                persona_recibe, 
                horarios, 
                metodo_pago, 
                monto_total, 
                comentario,
                estado_pago,
                fecha_creacion
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pendiente', NOW())
            ON DUPLICATE KEY UPDATE
                nombre = VALUES(nombre),
                direccion = VALUES(direccion),
                telefono = VALUES(telefono),
                correo = VALUES(correo),
                estado_pago = IF(estado_pago = 'pagado', 'pagado', 'pendiente')";
            
            $stmt_bold = $conn->prepare($sql_bold);
            if ($stmt_bold) {
                $stmt_bold->bind_param("sssssssds", 
                    $bold_order_id, $nombre, $direccion, $telefono, $correo, 
                    $persona_recibe, $horarios, $metodo_pago, $monto_limpio, $comentario
                );
                
                if ($stmt_bold->execute()) {
                    echo "<!-- DEBUG: Registro Bold creado/actualizado -->";
                } else {
                    echo "<!-- DEBUG: Error creando registro Bold: " . $stmt_bold->error . " -->";
                }
                $stmt_bold->close();
            }
            
            // Si el pago ya se completó (callback de Bold)
            if ($pago_completado) {
                echo "<!-- DEBUG: Pago Bold completado, actualizando estado -->";
                $sql_update_bold = "UPDATE pedidos SET estado_pago = 'pagado', fecha_pago = NOW() WHERE bold_order_id = ?";
                $stmt_update_bold = $conn->prepare($sql_update_bold);
                if ($stmt_update_bold) {
                    $stmt_update_bold->bind_param("s", $bold_order_id);
                    $stmt_update_bold->execute();
                    $stmt_update_bold->close();
                }
            }
        }
        
        // Si había un pedido_id temporal, actualizar los registros de pedido_detalle
        if ($pedido_id) {
            $sql_update = "UPDATE pedido_detalle SET pedido_id = ? WHERE pedido_id = ?";
            $stmt_update = $conn->prepare($sql_update);
            if ($stmt_update) {
                $stmt_update->bind_param("ii", $orden_id, $pedido_id);
                if ($stmt_update->execute()) {
                    echo "<!-- DEBUG: Detalles actualizados para orden: " . $orden_id . " -->";
                } else {
                    echo "<!-- DEBUG: Error actualizando detalles: " . $stmt_update->error . " -->";
                }
                $stmt_update->close();
            }
        }
        
        // Enviar emails
        $email_success = true;
        
        // EMAIL 1: Notificación al administrador y equipo
        $to_admin = "ventas@sequoiaspeed.com.co";
        $cc_admin = "jorgejosecardozo@gmail.com";
        $subject_admin = "Nueva orden de pedido #" . $orden_id;
        
        // Agregar información de Bold si aplica
        if ($metodo_pago === 'PSE Bold') {
            $subject_admin .= " - PSE Bold";
            if ($pago_completado) {
                $subject_admin .= " [PAGADO]";
            } else {
                $subject_admin .= " [PENDIENTE]";
            }
        }
        
        $message_admin = "Nueva orden recibida:\n\n";
        $message_admin .= "Orden #: " . $orden_id . "\n";
        
        // Información Bold si aplica
        if ($metodo_pago === 'PSE Bold' && !empty($bold_order_id)) {
            $message_admin .= "Bold Order ID: " . $bold_order_id . "\n";
            $message_admin .= "Estado de Pago: " . ($pago_completado ? "PAGADO" : "PENDIENTE") . "\n";
        }
        
        $message_admin .= "Nombre: " . $nombre . "\n";
        $message_admin .= "Teléfono: " . $telefono . "\n";
        $message_admin .= "Email: " . $correo . "\n";
        $message_admin .= "Dirección: " . $direccion . "\n";
        $message_admin .= "Persona que recibe: " . $persona_recibe . "\n";
        $message_admin .= "Horarios: " . $horarios . "\n";
        $message_admin .= "Método de pago: " . $metodo_pago . "\n";
        $message_admin .= "Monto: $" . number_format($monto_limpio, 0, ',', '.') . "\n\n";
        
        if ($pedido_final) {
            $message_admin .= $pedido_final . "\n\n";
        }
        
        if ($comentario) {
            $message_admin .= "Comentario: " . $comentario . "\n";
        }
        
        if ($archivo_nombre) {
            $message_admin .= "Comprobante adjunto: " . $archivo_nombre . "\n";
        }
        
        // Headers mejorados para el email del admin
        $headers_admin = "From: Sequoia Speed <ventas@sequoiaspeed.com.co>\r\n";
        $headers_admin .= "Reply-To: " . $correo . "\r\n";
        $headers_admin .= "Cc: " . $cc_admin . "\r\n";
        $headers_admin .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers_admin .= "X-Mailer: PHP/" . phpversion() . "\r\n";
        
        // EMAIL 2: Confirmación al cliente
        $subject_cliente = "Confirmación de tu pedido #" . $orden_id . " - Sequoia Speed";
        
        $message_cliente = "Hola " . $nombre . ",\n\n";
        $message_cliente .= "¡Gracias por tu pedido! Hemos recibido tu orden correctamente.\n\n";
        $message_cliente .= "DETALLES DE TU ORDEN:\n";
        $message_cliente .= "Número de orden: #" . $orden_id . "\n";
        $message_cliente .= "Fecha: " . date('d/m/Y H:i') . "\n";
        $message_cliente .= "Método de pago: " . $metodo_pago . "\n";
        $message_cliente .= "Monto total: $" . number_format($monto_limpio, 0, ',', '.') . "\n\n";
        
        if ($metodo_pago === 'PSE Bold') {
            if ($pago_completado) {
                $message_cliente .= "✅ PAGO CONFIRMADO\n";
                $message_cliente .= "Tu pago ha sido procesado exitosamente.\n\n";
            } else {
                $message_cliente .= "⏳ PAGO PENDIENTE\n";
                $message_cliente .= "Tu pago está siendo procesado. Te notificaremos cuando se confirme.\n\n";
            }
        }
        
        $message_cliente .= "DIRECCIÓN DE ENTREGA:\n";
        $message_cliente .= $direccion . "\n";
        $message_cliente .= "Persona que recibe: " . $persona_recibe . "\n";
        $message_cliente .= "Horarios: " . $horarios . "\n\n";
        
        if ($pedido_final) {
            $message_cliente .= "DETALLE DEL PEDIDO:\n";
            $message_cliente .= $pedido_final . "\n\n";
        }
        
        if ($comentario) {
            $message_cliente .= "Comentarios: " . $comentario . "\n\n";
        }
        
        $message_cliente .= "Te contactaremos pronto para coordinar la entrega.\n\n";
        $message_cliente .= "¡Gracias por confiar en Sequoia Speed Colombia!\n\n";
        $message_cliente .= "---\n";
        $message_cliente .= "Sequoia Speed Colombia\n";
        $message_cliente .= "Email: ventas@sequoiaspeed.com.co\n";
        $message_cliente .= "Teléfono: 3213260357";
        
        // Headers para el email del cliente
        $headers_cliente = "From: Sequoia Speed <ventas@sequoiaspeed.com.co>\r\n";
        $headers_cliente .= "Reply-To: ventas@sequoiaspeed.com.co\r\n";
        $headers_cliente .= "Bcc: jorgejosecardozo@gmail.com\r\n";
        $headers_cliente .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers_cliente .= "X-Mailer: PHP/" . phpversion() . "\r\n";
        
        // Preparar ruta del archivo adjunto si existe
        $archivo_adjunto_path = null;
        if ($archivo_nombre) {
            $archivo_adjunto_path = $upload_dir . $archivo_nombre;
        }
        
        // Enviar email al administrador (con adjunto si existe)
        $admin_enviado = enviar_email_mejorado($to_admin, $subject_admin, $message_admin, $headers_admin, $archivo_adjunto_path);
        
        // Enviar email al cliente (sin adjunto para mantener limpio)
        $cliente_enviado = enviar_email_mejorado($correo, $subject_cliente, $message_cliente, $headers_cliente);
        
        // Log del resultado
        if ($admin_enviado && $cliente_enviado) {
            error_log("✅ Ambos emails enviados exitosamente para orden #" . $orden_id);
        } else {
            if (!$admin_enviado) {
                error_log("❌ Error enviando email al administrador para orden #" . $orden_id);
            }
            if (!$cliente_enviado) {
                error_log("❌ Error enviando email de confirmación al cliente para orden #" . $orden_id);
            }
        }
        
        // Redirigir según el método de pago
        if ($metodo_pago === 'PSE Bold') {
            if ($pago_completado) {
                // Pago completado exitosamente
                header("Location: comprobante.php?orden=" . $orden_id . "&bold_success=1&bold_order_id=" . urlencode($bold_order_id));
            } else {
                // Redirigir con información de pago pendiente
                header("Location: comprobante.php?orden=" . $orden_id . "&bold_pending=1&bold_order_id=" . urlencode($bold_order_id));
            }
        } else {
            // Redirigir al comprobante normal
            header("Location: comprobante.php?orden=" . $orden_id);
        }
        exit;
    } else {
        echo "Error al ejecutar consulta: " . $stmt->error;
        echo "<!-- DEBUG SQL: " . $sql . " -->";
        echo "<!-- DEBUG Datos: pedido=$pedido_final, monto=$monto_limpio, nombre=$nombre -->";
    }
    
    $stmt->close();
} else {
    echo "Método no permitido";
}
?>